// With God's Help

const { v4: uuidv4 } = require("uuid");
const bcrypt = require("bcrypt");
const express = require("express");
const app = express();
app.use(express.json());
const port = 8;

let users = [
  {
    id: "1",
    email: "ai1@ai.com",
    password: "ai=avraham&itshack",
  },
  {
    id: "2",
    email: "ai2@ai.com",
    password: "ai=avraham&itshack",
  },
  {
    id: "3",
    email: "ai3@ai.com",
    password: "ai=avraham&itshack",
  },
];

users.map((user) => {
  user.id = uuidv4();
  user.password = bcrypt.hashSync(user.password, 12);
});

app.get("/users", (req, resp) => {
  resp.send(users);
});

app.get("/users/:id", (req, resp) => {
  const id = req.params.id;
  const user = users.find((element) => element.id === id);
  if (user) {
    resp.send(user);
  } else {
    resp.status(404).send("Error");
  }
});

app.post("/users/", (req, resp) => {
  const user = req.body;
  user.id = uuidv4();
  user.password = bcrypt.hashSync(user.password, 12);
  users.push(user);
  resp.send(users);
});

app.post("/users/login/", (req, resp) => {
  const reqBody = req.body;
  const password = reqBody.password;
  const email = reqBody.email;
  try {
    let user = users.find((user) => user.email === email);
    let result = bcrypt.compareSync(password, user.password);
    if (result) {
      resp.send("User is connected");
    } else {
      resp.send("Wrong credentials");
    }
  } catch {
    resp.status(401).send("Wrong credentials");
  }
});

app.put("/users/:id", (req, resp) => {
  const update = req.body;
  const id = req.params.id;
  const user = users.find((user) => user.id === id);
  const userIndex = users.indexOf(user);
  if (user) {
    users[userIndex] = req.body;
    resp.send(update);
  } else {
    resp.status(404).send("Error couldn't update the user");
  }
});

app.delete("/users/:id", (req, resp) => {
  const id = req.params.id;
  users = users.filter((user) => user.id !== id);
  resp.send("Successfully Deleted!");
});

app.listen(port, () => {
  console.log("Your server is running...");
});
