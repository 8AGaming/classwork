// With God's Help

// 1.1
const ROOT = document.getElementById("root");
const createElement = (type, anchorEl, node, className = "") => {
  const ELEMENT = document.createElement(type);
  anchorEl.appendChild(ELEMENT);
  ELEMENT.textContent = node;
  if (className !== "") {
    ELEMENT.classList.add(className);
  }
  return ELEMENT;
};
const createCard = (anchorElement, data) => {
  const CARD = createElement("div", anchorElement, "", "card");
  const NAME = createElement("div", CARD, "", "text");
  NAME.textContent = `Name: ${data.title} ${data.first} ${data.last}`;
  const EMAIL = createElement("div", CARD, "", "text");
  EMAIL.textContent = `Email: ${data.email}`;
  const IMAGE = createElement("img", CARD, "", "image");
  IMAGE.src = data.picture.large;
  const AGE = createElement("div", CARD, "", "text");
  AGE.textContent = `Age:${data.age}`;
};
const getData = async () => {
  try {
    const resp = await fetch("https://randomuser.me/api");
    if (resp.ok) {
      let data = await resp.json();
      const {
        name: { title, first, last },
        email,
        dob: { age },
        picture,
      } = data.results[0];
      return { title, first, last, email, age, picture };
    } else {
      throw new Error(`Error! Status ${resp.status}`);
    }
  } catch (error) {
    console.error(error.message);
  }
};
const button1 = document.getElementsByClassName("buttons")[0];
const CARD_DIV = createElement("div", ROOT);
button1.addEventListener("click", async () => {
  createCard(CARD_DIV, await getData());
});

// 1.2
let users = [];
const getData2 = async () => {
  try {
    const resp = await fetch("https://randomuser.me/api?gender=male");
    if (resp.ok) {
      const data = await resp.json();
      const {
        name: { title, first, last },
        email,
        dob: { age },
        picture,
      } = data.results[0];
      return { title, first, last, email, age, picture };
    } else {
      throw new Error(`Error! Status ${resp.status}`);
    }
  } catch (error) {
    console.error(error.message);
  }
};
const button2 = createElement("button", ROOT, "Click Me 2", "buttons");
const CARD_DIV2 = createElement("div", ROOT);
button2.addEventListener("click", async () => {
  while (users.length !== 5) {
    users.push(await getData2());
  }
  users.forEach((user) => createCard(CARD_DIV2, user));
});

// 2
// My API: 824d8103fc5e417985190fcd50dda949
const getJoke = async () => {
  try {
    const resp = await fetch("https://api.chucknorris.io/jokes/random");
    if (resp.ok) {
      const data = await resp.json();
      return data.value;
    }
  } catch (error) {
    console.error(error.message);
  }
};
const JOKE_BUTTON = createElement("button", ROOT, "Generate Joke", "buttons");
const JOKE_DIV = createElement("div", ROOT, "", "joke_card");
JOKE_TEXT = createElement("div", JOKE_DIV, "", "text");
JOKE_BUTTON.addEventListener("click", async () => {
  JOKE_DIV.style.visibility = "visible";
  JOKE_DIV.style.opacity = "1";
  JOKE_TEXT.textContent = await getJoke();
});

// 3
const SHOW_PRODUCTS = createElement("button", ROOT, "Show Products", "buttons");
const createProductCard = (anchorElement, data, index) => {
  const CARD = createElement("div", anchorElement, "", "card");
  const TITLE = createElement("div", CARD, "", "text");
  TITLE.textContent = `Title: ${data.title}`;
  const PRICE = createElement("div", CARD, "", "text");
  PRICE.textContent = `Price: ${data.price}`;
  const DESCRIPTION = createElement("div", CARD, "", "text");
  DESCRIPTION.textContent = `Description: ${data.description}`;
  const CATEGORY = createElement("div", CARD, "", "text");
  CATEGORY.textContent = `Category:${data.category}`;
  const IMAGE_DIV = createElement("div", CARD, "", "image_div");
  const IMAGE = createElement("img", IMAGE_DIV, "", "image3");
  IMAGE.src = data.image;
  IMAGE.style.zIndex = 0;
  CARD.style.zIndex = 1;
};
const getProducts = async () => {
  try {
    const resp = await fetch("https://fakestoreapi.com/products");
    if (resp.ok) {
      const data = await resp.json();
      return data;
    }
  } catch (error) {
    console.error(error.message);
  }
};
SHOW_PRODUCTS_DIV = createElement("div", ROOT, "", "products_div");
SHOW_PRODUCTS.addEventListener("click", async () => {
  const products = await getProducts();
  products.forEach((product, index) => {
    createProductCard(SHOW_PRODUCTS_DIV, product, index);
  });
});

// 4
const FORM = createElement("form", ROOT, "", "form");
const firstNameLabel = createElement("label", FORM, "First Name", "form_label");
const firstNameInput = createElement("input", FORM, "", "form_input");
const lastNameLabel = createElement("label", FORM, "Last Name", "form_label");
const lastNameInput = createElement("input", FORM, "", "form_input");
const emailLabel = createElement("label", FORM, "Email", "form_label");
const emailInput = createElement("input", FORM, "", "form_input");
const ageLabel = createElement("label", FORM, "Age", "form_label");
const ageInput = createElement("input", FORM, "", "form_input");

const addUser = async (first, last, email, age) => {
  const firstName = first.value;
  const lastName = last.value;
  const email_value = email.value;
  const age_value = age.value;
  const obj = {
    name: firstName,
    last: lastName,
    email: email_value,
    age: age_value,
  };
  const send = {
    method: "post",
    body: JSON.stringify(obj),
    headers: {
      "Content-Type": "application/json",
    },
  };
  const resp = await fetch("https://jsonplaceholder.typicode.com/users", send);
  if (resp.ok) {
    const data = await resp.json();
    console.log(data);
  } else {
    throw new Error("Error " + resp.status);
  }
};
const SEND = createElement("input", FORM, "", "buttons");
SEND.value = "Add User";
SEND.type = "button";
SEND.addEventListener("click", async () => {
  await addUser(firstNameInput, lastNameInput, emailInput, ageInput);
});
