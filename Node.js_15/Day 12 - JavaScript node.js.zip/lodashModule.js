const lodash = require("lodash");
const arrayFromString = (string) => lodash.words(string);
const stringFromArray = (array) => lodash.join(lodash.reverse(array), " ");
const removeDuplicateFromArray = (array) => lodash.uniq(array);
module.exports = {
  arrayFromString,
  stringFromArray,
  removeDuplicateFromArray,
};
