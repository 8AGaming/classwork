// With God's Help

// 1
// const fs = require("fs");
// const lodashModule = require("./lodashModule");
// const returnData = () => {
//   const readPromise = new Promise((resolve, reject) => {
//     fs.readFile("file.txt", "utf-8", (err, data) => {
//       if (err) reject(err);
//       else resolve(data);
//     });
//   });
//   return readPromise;
// };

// // console.log(data);
// async function main(params) {
//   const data = await returnData();
//   const words = lodashModule.arrayFromString(data);
//   // const words = lodash.words(data);

//   const reversedWords = [...words].reverse();
//   // console.log(reversedWords);
//   // console.log(words.length);
//   const reversedData = lodashModule.stringFromArray(words);
//   // console.log(reversedData);
//   const noDuplicateWordArray =
//     lodashModule.removeDuplicateFromArray(reversedWords);
//   // console.log(noDuplicateWordArray);
//   // console.log(noDuplicateWordArray.length);

//   // const obj = {};
//   const upperCaseWords = noDuplicateWordArray.map((word) => word.toUpperCase());
//   const moreThanFiveLetters = noDuplicateWordArray.filter(
//     (word) => word.length > 5
//   );
//   // console.log(upperCaseWords);
//   // console.log(moreThanFiveLetters);
//   // console.log(challengeResult);
//   const letterCounter = (word) => {
//     let counter = 0;
//     for (let i = 0; i < word.length; i++) {
//       if (
//         word[i] === "a" ||
//         word[i] === "e" ||
//         word[i] === "i" ||
//         word[i] === "o" ||
//         word[i] === "u"
//       ) {
//         counter++;
//       }
//     }
//     return counter;
//   };

//   const challengeArray = noDuplicateWordArray.filter(
//     (word) =>
//       word.includes("a") ||
//       word.includes("e") ||
//       word.includes("i") ||
//       word.includes("o") ||
//       word.includes("u")
//   );

//   const result = challengeArray.map((word) => {
//     return { word, vowelCount: letterCounter(word) };
//   });
//   console.log(result);
//   //   fs.writeFile("challenge.json", result, (err) => {
//   //     console.log(err);
//   //   });
// }
// main();

// // const challengeResult = { words: [] };
// // noDuplicateWordArray.forEach((word) => {
// //   let vowels_count = 0;
// //   Array.from(word).forEach((letter) => {
// //     letter_lower = letter.toLowerCase();
// //     if (
// //       letter_lower === "a" ||
// //       letter_lower === "e" ||
// //       letter_lower === "i" ||
// //       letter_lower === "o" ||
// //       letter_lower === "u"
// //     ) {
// //       vowels_count++;

// //       challengeResult.push({ word, vowelCount: vowels_count });
// //     }
// //   });
// // });
// // console.log(challengeResult);
// // const JSON_DATA_PARSED = JSON.stringify(challengeResult);
// // console.log(JSON_DATA_PARSED);
// // fs.writeFile("challenge.json", result, (error) => {
// //   console.error(error);
// // });
// With God's Help

// 2

// const fs = require("fs");
// const javascriptModule = require("./javascriptModule");
// const returnData = () => {
//   const readPromise = new Promise((resolve, reject) => {
//     fs.readFile("file.txt", "utf-8", (err, data) => {
//       if (err) reject(err);
//       else resolve(data);
//     });
//   });
//   return readPromise;
// };

// // console.log(data);
// async function main(params) {
//   const data = await returnData();
//   const words = javascriptModule.arrayFromString(data);
//   console.log(words);
//   // const words = lodash.words(data);

//   const reversedWords = [...words].reverse();
//   // console.log(reversedWords);
//   // console.log(words.length);
//   const reversedData = javascriptModule.stringFromArray(reversedWords);
//   // console.log(reversedData);
//   const noDuplicateWordArray =
//     javascriptModule.removeDuplicateFromArray(reversedWords);
//   // console.log(noDuplicateWordArray);
//   // console.log(noDuplicateWordArray.length);

//   // const obj = {};
//   const upperCaseWords = noDuplicateWordArray.map((word) => word.toUpperCase());
//   const moreThanFiveLetters = noDuplicateWordArray.filter(
//     (word) => word.length > 5
//   );

//   const letterCounter = (word) => {
//     let counter = 0;
//     for (let i = 0; i < word.length; i++) {
//       if (
//         word[i] === "a" ||
//         word[i] === "e" ||
//         word[i] === "i" ||
//         word[i] === "o" ||
//         word[i] === "u"
//       ) {
//         counter++;
//       }
//     }
//     return counter;
//   };

//   const challengeArray = noDuplicateWordArray.filter(
//     (word) =>
//       word.includes("a") ||
//       word.includes("e") ||
//       word.includes("i") ||
//       word.includes("o") ||
//       word.includes("u")
//   );

//   const result = challengeArray.map((word) => {
//     return { word, vowelCount: letterCounter(word) };
//   });
//   console.log(result);
//   //   fs.writeFile("challenge.json", result, (err) => {
//   //     console.log(err);
//   //   });
// }
// main();
