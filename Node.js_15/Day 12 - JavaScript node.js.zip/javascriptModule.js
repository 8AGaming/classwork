const arrayFromString = (string) => string.split(" ").filter((e) => e !== "");
const stringFromArray = (array) => array.join(" ");
const removeDuplicateFromArray = (array) => [...new Set(array)];
module.exports = {
  arrayFromString,
  stringFromArray,
  removeDuplicateFromArray,
};
