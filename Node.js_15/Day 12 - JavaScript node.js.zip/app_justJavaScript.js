// With God's Help

// 1
const fs = require("fs");
const lodashModule = require("./javascriptModule");
const returnData = () => {
  const readPromise = new Promise((resolve, reject) => {
    fs.readFile("file.txt", "utf-8", (err, data) => {
      if (err) reject(err);
      else resolve(data);
    });
  });
  return readPromise;
};

// console.log(data);
async function main(params) {
  const data = await returnData();
  const words = lodashModule.arrayFromString(data);
  // const words = lodash.words(data);

  const reversedWords = [...words].reverse();
  // console.log(reversedWords);
  // console.log(words.length);
  const reversedData = lodashModule.stringFromArray(words);
  // console.log(reversedData);
  const noDuplicateWordArray =
    lodashModule.removeDuplicateFromArray(reversedWords);
  // console.log(noDuplicateWordArray);
  // console.log(noDuplicateWordArray.length);

  // const obj = {};
  const upperCaseWords = noDuplicateWordArray.map((word) => word.toUpperCase());
  const moreThanFiveLetters = noDuplicateWordArray.filter(
    (word) => word.length > 5
  );
  // console.log(upperCaseWords);
  // console.log(moreThanFiveLetters);
  // console.log(challengeResult);
  const letterCounter = (word) => {
    let counter = 0;
    for (let i = 0; i < word.length; i++) {
      if (
        word[i] === "a" ||
        word[i] === "e" ||
        word[i] === "i" ||
        word[i] === "o" ||
        word[i] === "u"
      ) {
        counter++;
      }
    }
    return counter;
  };

  const challengeArray = noDuplicateWordArray.filter(
    (word) =>
      word.includes("a") ||
      word.includes("e") ||
      word.includes("i") ||
      word.includes("o") ||
      word.includes("u")
  );

  const result = JSON.stringify(
    challengeArray.map((word) => {
      return { word, vowelCount: letterCounter(word) };
    })
  );
  console.log(result);
  //   fs.writeFile("challenge.json", result, (err) => {
  //     console.log(err);
  //   });
}
main();
